(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 20:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(664);
;// CONCATENATED MODULE: ./components/navbar/DropItems.js
const DropItems = [{
  title: "Drop 01",
  path: "/",
  cName: "dropdown-link"
}, {
  title: "Drop 02",
  path: "/",
  cName: "dropdown-link"
}, {
  title: "Drop 03",
  path: "/",
  cName: "dropdown-link"
}, {
  title: "Drop 04",
  path: "/",
  cName: "dropdown-link"
}];
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(282);
;// CONCATENATED MODULE: ./components/navbar/Dropdown.jsx





function Dropdown() {
  const {
    0: click,
    1: setClick
  } = (0,external_react_.useState)(false);

  const handleClick = () => setClick(!click);

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      onClick: handleClick,
      className: click ? "dropdownMenu hidden" : "dropdownMenu",
      children: DropItems.map((item, index) => {
        return /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex justify-center px-3 py-4 rounded shadow hover:bg-[#70161E] hover:text-white transition duration-500 ease-in-out",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            className: "dropdownMenu",
            href: item.path,
            passHref: true,
            onClick: () => setClick(false),
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              children: item.title
            })
          })
        }, index);
      })
    })
  });
}
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(675);
;// CONCATENATED MODULE: ./components/navbar/logos/LogoMarca.jsx




function LogoMarca() {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: " flex items-center mt-2 ml-4 cursor-pointer drop-shadow hover:drop-shadow-none",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/",
        passHref: true,
        children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/logo/logoMarca.svg",
          alt: "Rede Sem Fronteiras",
          width: 256,
          height: 85
        })
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/navbar/IconDown.jsx

function IconDown() {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "animate-bounce",
    children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      className: "h-3 w-3",
      fill: "none",
      viewBox: "0 0 24 24",
      stroke: "currentColor",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2",
        d: "M19 13l-7 7-7-7m14-8l-7 7-7-7"
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/navbar/IconClose.jsx

function IconClose() {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "",
    children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      className: "h-7 w-7",
      fill: "none",
      viewBox: "0 0 24 24",
      stroke: "currentColor",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2",
        d: "M6 18L18 6M6 6l12 12"
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/navbar/IconBars.jsx

function IconBars() {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "",
    children: /*#__PURE__*/jsx_runtime_.jsx("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      className: "h-7 w-7",
      fill: "none",
      viewBox: "0 0 24 24",
      stroke: "currentColor",
      children: /*#__PURE__*/jsx_runtime_.jsx("path", {
        strokeLinecap: "round",
        strokeLinejoin: "round",
        strokeWidth: "2",
        d: "M4 6h16M4 12h16M4 18h16"
      })
    })
  });
}
;// CONCATENATED MODULE: ./components/navbar/MenuItems.js
const MenuItems = [{
  title: "Home",
  link: "/",
  cName: "dropdown-link"
}, {
  title: "Link 02",
  link: "/link-02",
  cName: "dropdown-link"
}, {
  title: "Link 03",
  link: "/link-03",
  cName: "dropdown-link"
}, {
  title: "Link 04",
  link: "/link-04",
  cName: "dropdown-link"
}, {
  title: "Link 05",
  link: "/link-05",
  cName: "dropdown-link"
}, {
  title: "Contact",
  link: "/contact",
  cName: ""
}];
;// CONCATENATED MODULE: ./components/navbar/Navbar.jsx











function Navbar() {
  const {
    0: click,
    1: setClick
  } = (0,external_react_.useState)(false);
  const {
    0: dropdown,
    1: setDropdown
  } = (0,external_react_.useState)(false);

  const handleClick = () => setClick(!click);

  const closeMobileMenu = () => setClick(false);

  const onMouseEnter = () => {
    if (window.innerWidth < 960) {
      setDropdown(false);
    } else {
      setDropdown(true);
    }
  };

  const onMouseLeave = () => {
    if (window.innerWidth < 960) {
      setDropdown(false);
    } else {
      setDropdown(false);
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
      className: "bg-gray-50 border-b shadow flex sm:justify-evenly items-center h-[100px] sticky top-0 z-[1000]",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center",
        children: [/*#__PURE__*/jsx_runtime_.jsx(LogoMarca, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "menuIcon",
          onClick: handleClick,
          children: click ? /*#__PURE__*/jsx_runtime_.jsx(IconClose, {}) : /*#__PURE__*/jsx_runtime_.jsx(IconBars, {})
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: click ? "nav-menu active" : "nav-menu",
        children: [MenuItems.map((menu, index) => {
          return /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "header-link group",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: menu.link,
              children: /*#__PURE__*/jsx_runtime_.jsx("a", {
                onClick: closeMobileMenu,
                children: /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "span",
                  children: menu.title
                })
              })
            })
          }, index);
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "header-link group",
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "hidden lg:flex items-center uppercase font-medium mx-auto text-sm text-white md:text-purple-600 z-10",
            onMouseEnter: onMouseEnter,
            onMouseLeave: onMouseLeave,
            children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "/",
              passHref: true,
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
                className: "md:py-8 flex items-center",
                onClick: closeMobileMenu,
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  children: "DropDown"
                }), /*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "hidden md:flex",
                  children: /*#__PURE__*/jsx_runtime_.jsx(IconDown, {})
                })]
              })
            }), dropdown && /*#__PURE__*/jsx_runtime_.jsx(Dropdown, {})]
          })
        })]
      })]
    })
  });
}
;// CONCATENATED MODULE: ./components/Layout.js




const Layout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "mx-auto",
    children: [/*#__PURE__*/jsx_runtime_.jsx(Navbar, {}), children]
  });
};

/* harmony default export */ const components_Layout = (Layout);
;// CONCATENATED MODULE: ./pages/_app.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(components_Layout, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
  });
}

/* harmony default export */ const _app = (MyApp);

/***/ }),

/***/ 325:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 695:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 378:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 162:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 248:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 372:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 747:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 456:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 620:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 297:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 282:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [664,675], () => (__webpack_exec__(20)));
module.exports = __webpack_exports__;

})();