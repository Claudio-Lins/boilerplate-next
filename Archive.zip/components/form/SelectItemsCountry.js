export const SelectItemsCountry = [
  {
    name: "Brasil",
    value: "brasil",
    cName: "",
  },
  {
    name: "Portugal",
    value: "portugal",
    cName: "",
  },
  {
    name: "Nigéria",
    value: "nigeria",
    cName: "",
  },
  {
    name: "Outro",
    value: "outro",
    cName: "",
  },
];
