export const MenuItems = [
  {
    title: "Home",
    section: "linkOne",
    cName: "",
  },
  {
    title: "Link 02",
    section: "linkTwo",
    cName: "",
  },
  {
    title: "Link 03",
    section: "linkThree",
    cName: "",
  },
  {
    title: "Link 04",
    section: "linkFour",
    cName: "",
  },
  {
    title: "Link 05",
    section: "linkFive",
    cName: "",
  },
  {
    title: "Contacto",
    section: "contacto",
    cName: "",
  },
];
