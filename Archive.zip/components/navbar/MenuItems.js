export const MenuItems = [
  {
    title: "Home",
    link: "/",
    cName: "dropdown-link",
  },
  {
    title: "Link 02",
    link: "/link-02",
    cName: "dropdown-link",
  },
  {
    title: "Link 03",
    link: "/link-03",
    cName: "dropdown-link",
  },
  {
    title: "Link 04",
    link: "/link-04",
    cName: "dropdown-link",
  },
  {
    title: "Link 05",
    link: "/link-05",
    cName: "dropdown-link",
  },
  {
    title: "Contact",
    link: "/contact",
    cName: "",
  },
];
