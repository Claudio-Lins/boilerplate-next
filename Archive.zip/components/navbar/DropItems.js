export const DropItems = [
  {
    title: "Drop 01",
    path: "/",
    cName: "dropdown-link",
  },

  {
    title: "Drop 02",
    path: "/",
    cName: "dropdown-link",
  },

  {
    title: "Drop 03",
    path: "/",
    cName: "dropdown-link",
  },

  {
    title: "Drop 04",
    path: "/",
    cName: "dropdown-link",
  },
];
